# Visual Review Notes

## Estado Atual
- Layout full-screen: OK
- Fundo preto: OK
- Partículas de fundo: OK (discretas, flutuando)
- Vinheta: OK
- Símbolo central Dota 2: OK (imagem 3D gerada, flutuando)
- Glow vermelho ao redor: OK (visível no hover)
- Texto "ACESSO DETECTADO": OK (aparece no hover)
- Textos laterais: OK (todos em português, posicionados corretamente)
- HUD status top-right: OK (vagas, status, nível de acesso)
- Tagline "12 HORAS. UMA NOITE. SEM PAUSA.": OK (acima do símbolo)
- Tipografia: OK (Rajdhani, JetBrains Mono, Space Grotesk)

## Observações de melhoria
- O símbolo central parece um pouco grande com a borda vermelha ao redor — a borda é do glow/QR overlay
- O "ACESSO DETECTADO" está aparecendo na screenshot (hover state capturado)
- Precisa verificar se o formulário abre corretamente no clique
- A instrução "[ APROXIME O CURSOR ]" deve aparecer no idle state
