# NONSTOP DOTA 2 — Brainstorm de Design

## Contexto
Landing page full-screen de pré-inscrição para evento presencial de Dota 2 em lan house. 20 vagas limitadas. Conceito: "portal secreto de acesso". Estética premium, escura, misteriosa, tecnológica e gamer.

---

<response>
## Ideia 1 — "Vault Protocol" (Brutalismo Digital Cinematográfico)
<probability>0.06</probability>

**Design Movement:** Brutalismo Digital + Cinema Noir Sci-Fi (inspirado em interfaces de Blade Runner 2049, Alien Isolation, terminais militares)

**Core Principles:**
1. Tipografia como arquitetura — letras condensadas gigantes que definem a estrutura visual
2. Ausência como tensão — o vazio preto é tão importante quanto o conteúdo
3. Dados como ornamento — números, coordenadas e status substituem decoração
4. Acesso como ritual — cada interação é um passo de desbloqueio

**Color Philosophy:** Preto absoluto (#000000) como base. Cinza frio (#8A8A8A) para dados secundários. Vermelho sangue (#8B0000) apenas como acento de alerta/ativação — nunca decorativo. Branco puro (#FFFFFF) apenas para o elemento mais importante da tela.

**Layout Paradigm:** Grid militar assimétrico. Textos posicionados em coordenadas fixas nas bordas da tela como readouts de um HUD tático. Centro completamente vazio exceto pelo símbolo-portal. Nenhum alinhamento centralizado de blocos de texto.

**Signature Elements:**
1. Linhas de scan horizontais ultra-finas que percorrem a tela periodicamente
2. Números de coordenadas/timestamps nos cantos como metadata de um sistema classificado
3. Cursor que deixa rastro de caracteres monospace que se dissolvem

**Interaction Philosophy:** Cada hover é uma "leitura de acesso". O sistema reconhece o usuário progressivamente. Feedback visual é sempre textual (mensagens de terminal) antes de ser gráfico.

**Animation:** Glitch sutil no texto ao aparecer. Scanlines lentas. Símbolo central com rotação micro (0.5deg) e flutuação vertical de 4px. Pulso de luz vermelha no clique. Tudo em timing lento e deliberado — nada rápido.

**Typography System:** Rajdhani 700 para títulos/dados grandes. Space Grotesk 400 para corpo. Monospace (JetBrains Mono) para dados de sistema/HUD.
</response>

---

<response>
## Ideia 2 — "Digital Shrine" (Minimalismo Sagrado Tecnológico)
<probability>0.04</probability>

**Design Movement:** Minimalismo Sagrado + Arte Generativa (inspirado em teamLab, Ryoji Ikeda, instalações de arte digital japonesa)

**Core Principles:**
1. O vazio é sagrado — 85% da tela deve ser espaço negativo
2. Geometria como linguagem — formas geométricas comunicam mais que palavras
3. Luz como narrativa — a iluminação do símbolo central conta a história
4. Silêncio visual — pouquíssimos elementos, cada um com peso máximo

**Color Philosophy:** Preto profundo (#050505) com micro-textura de noise. Branco quente (#E8E4E0) para tipografia primária. Dourado escuro (#8B7355) como acento sagrado/premium. Vermelho Dota (#C23B22) apenas no momento de ativação.

**Layout Paradigm:** Composição zen assimétrica. Símbolo central ligeiramente acima do centro geométrico. Textos em tamanho 10-11px posicionados como inscrições em uma parede de templo — espaçados, respirando, quase sussurrados.

**Signature Elements:**
1. Partículas que se movem como poeira em um feixe de luz — orgânicas, lentas, gravitacionais
2. Círculo de luz sutil ao redor do símbolo que pulsa como respiração
3. Textos que aparecem letra por letra como se fossem gravados

**Interaction Philosophy:** O mouse é uma lanterna. Onde ele passa, revela. O QR emerge da escuridão como um artefato sendo descoberto. A interação é contemplativa, não agressiva.

**Animation:** Respiração lenta do símbolo (scale 1.0 → 1.02 em 4s). Partículas com física gravitacional real. Textos com fade-in de 2s cada. Transição do formulário como uma cortina de luz se abrindo.

**Typography System:** Cormorant Garamond 300 para frases conceituais. Space Grotesk 500 para dados/labels. Tracking extremamente aberto (+0.3em) em textos pequenos.
</response>

---

<response>
## Ideia 3 — "Warzone Terminal" (Interface Tática de Arena)
<probability>0.08</probability>

**Design Movement:** UI de Jogos Competitivos + Cyberpunk Tático (inspirado em The International broadcast UI, Valorant agent select, interfaces de Warzone/Apex)

**Core Principles:**
1. Informação como poder — cada dado na tela parece intel classificada
2. Bordas cortantes — ângulos de 45° e clips geométricos definem as áreas
3. Vermelho como perigo — a cor vermelha Dota é usada como indicador de urgência/escassez
4. Layers de profundidade — elementos em diferentes camadas de opacidade criam profundidade

**Color Philosophy:** Preto grafite (#0A0A0A) como base. Cinza aço (#2A2A2E) para painéis. Vermelho Dota (#FF4444) como cor de ação/urgência. Azul neon frio (#00D4FF) como cor de sistema/dados. Branco (#F0F0F0) para texto primário.

**Layout Paradigm:** HUD de jogo competitivo. Cantos da tela com painéis angulados (clip-path). Centro aberto como uma arena. Barras de status nas bordas. Informações distribuídas como um overlay de broadcast esportivo.

**Signature Elements:**
1. Bordas com clip-path angulado (cantos cortados a 45°) nos painéis de informação
2. Barra de progresso de vagas estilizada como health bar de jogo
3. Micro-animações de "data stream" — números que mudam rapidamente antes de estabilizar

**Interaction Philosophy:** Hover ativa estados de "target lock". Clique é "confirm action". Tudo parece que o usuário está operando um sistema de matchmaking real. Feedback sonoro implícito no visual (flashes, pulsos).

**Animation:** Elementos entram com slide + fade de direções diferentes. Números fazem "slot machine" antes de parar. Símbolo central tem rotação lenta no eixo Y (perspectiva 3D). Glow pulsa no ritmo de um heartbeat. Partículas são faíscas elétricas.

**Typography System:** Orbitron 700 para títulos/números grandes. Rajdhani 600 para subtítulos. Space Grotesk 400 para corpo. Tudo em uppercase com tracking aberto.
</response>

---

## Decisão

**Abordagem escolhida: Ideia 1 — "Vault Protocol" (Brutalismo Digital Cinematográfico)**

Esta abordagem é a que melhor atende ao briefing porque:
- O conceito de "portal secreto" se traduz perfeitamente em uma estética de terminal/vault classificado
- O brutalismo digital cria a sensação de exclusividade e mistério sem ser genérico
- A paleta extremamente restrita (preto, cinza, vermelho) é premium e cinematográfica
- O uso de tipografia como arquitetura permite criar impacto visual sem depender de assets pesados
- A interação progressiva de "desbloqueio" reforça a narrativa de acesso limitado
- O vazio intencional cria tensão e foco no elemento central
